# AI Designer Portfolio

- slug: `ai-designer-portfolio`
- scope: page
- theme: light
- source folder in the original repo: free (category "Landing Page")
- summary: Creative-studio portfolio "V Vortex": hero, marquee, testimonial quote, pricing cards, projects, footer. White background with dark-teal ink (#051A24), PP Neue Montreal + PP Mondwest accent words.

Everything below the line is the original prompt, verbatim.

---

Build a single-page creative studio portfolio landing page for "V Vortex" -- the studio of Sarah Vortex, a former Apple designer. Use React + TypeScript + Vite + Tailwind CSS. Use lucide-react for icons. No other UI libraries.

FONTS:

Body: "PP Neue Montreal" loaded via @font-face from these URLs:
Book (400): https://assets.website-files.com/6009ec8cda7f305645c9d91b/60176f9bb43e36419997ecfe_PPNeueMontreal-Book.otf
Medium (500): https://assets.website-files.com/6009ec8cda7f305645c9d91b/60176f9b39c5673e51a86f5a_PPNeueMontreal-Medium.otf
Display/Serif accent: "PP Mondwest" loaded from a local /PPMondwest-Regular.woff2 file. Applied inline via style={{ fontFamily: "'PP Mondwest', serif" }} on accent words like "next wave", "bold way", "builders", etc.
Set body font-family to: 'PP Neue Montreal', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif

COLOR PALETTE:

Primary dark: #051A24
Dark: #0D212C
Muted dark: #273C46
Light text: #F6FCFF
Light muted: #E0EBF0
Background: white
No purple, indigo, or violet hues anywhere.

GLOBAL ANIMATIONS (in index.css):

marquee keyframe: translateX(0) to translateX(-50%), 30s linear infinite on desktop, 10s on mobile (max-width: 767px).
fadeInUp keyframe: from opacity: 0; translateY(30px) to opacity: 1; translateY(0), 0.8s ease-out forwards. Class: .animate-fade-in-up with initial opacity: 0.

CUSTOM HOOK: useInViewAnimation

IntersectionObserver-based hook. Returns { ref, isInView }. isInView flips to true once when the element enters viewport (threshold 0.1). Never resets. Used on every section for staggered animate-fade-in-up entrance animations with incremental animationDelay (0.1s, 0.2s, 0.3s, etc.).

REUSABLE BUTTON COMPONENT:

Three variants -- primary, secondary, tertiary. All use: px-7 py-3 rounded-full font-medium text-sm transition-colors whitespace-nowrap.

primary: bg-[#051A24] text-white hover:bg-[#0D212C] with multi-layer shadow
secondary: bg-white text-[#051A24] with shadow
tertiary: Same as secondary but adds inset shadow
Renders as <a> if href is provided, otherwise <button>.

PAGE SECTIONS (top to bottom):

1. HERO SECTION (max-width 440px, centered, px-6, pt-12 md:pt-16)
Logo: "V Vortex" in PP Mondwest, text-[32px] md:text-[40px] lg:text-[44px], font-semibold, color #051A24
Tagline: "The creative studio of Sarah Vortex" -- font-mono, text-xs md:text-sm, color #051A24
Heading: "Build the next wave, the bold way." with "next wave" and "bold way." in PP Mondwest serif.
Description: Three paragraphs about Apple background, studio philosophy, and "$25,000/month" pricing.
Two buttons: "Start a chat" (primary) and "View projects" (secondary).

2. INFINITE IMAGE MARQUEE (full width, mt-16 md:mt-20, mb-16)
Uses 8 GIF URLs from motionsites.ai, duplicated for seamless looping.
Each image: h-[280px] md:h-[500px] object-cover mx-3 rounded-2xl shadow-lg

3. TESTIMONIAL QUOTE SECTION (centered, max-w-2xl)
Large quote with "Apple" in PP Mondwest serif.
Author: "Sarah Vortex" in italic.
Three brand names and a parallax-scrolling image.

4. PRICING SECTION (max-w-7xl, cards right-aligned)
Two cards: Monthly Partnership (dark) and Custom Project (white), both $25,000.

5. TESTIMONIAL CAROUSEL (max-w-7xl, auto-scrolling every 3s)
5 testimonial cards with avatars from Pexels.
Navigation arrows below carousel.

6. PROJECTS SECTION (max-w-[1200px])
3 project cards with GIF previews from motionsites.ai.

7. PARTNER CTA SECTION with mouse trail effect spawning preview images.

8. FOOTER with links and copyright bar.

9. FIXED BOTTOM NAV floating pill with "V" logo and "Start a chat" button.
